package dev.poldy.lab;

import android.graphics.*;
import android.os.*;
import android.view.*;
import java.lang.reflect.*;
import java.io.*;
import java.util.concurrent.*;

/** Fixed outer-primary mapping. Only the application's logical viewport changes. */
final class StableDisplay implements AutoCloseable {
    private final Object wm;
    private final Class<?> api=Class.forName("android.view.IWindowManager");
    private final int density;
    private SurfaceControl sourceParent,source,live;
    private final ScheduledExecutorService projector=Executors.newSingleThreadScheduledExecutor();
    private final Method project;
    private final IBinder outerToken;
    private volatile long pinUntil;
    private volatile boolean closed;
    private boolean inner;
    private final java.lang.Process guard;
    private final PrintWriter heartbeat;
    StableDisplay(String apkPath)throws Exception {
        IBinder binder=(IBinder)Class.forName("android.os.ServiceManager").getMethod("getService",String.class).invoke(null,"window");
        wm=Class.forName("android.view.IWindowManager$Stub").getMethod("asInterface",IBinder.class).invoke(null,binder);
        density=(int)api.getMethod("getBaseDisplayDensity",int.class).invoke(wm,0);
        outerToken=(IBinder)SurfaceControl.class.getMethod("getPhysicalDisplayToken",long.class).invoke(null,4630947123231501204L);
        project=SurfaceControl.Transaction.class.getMethod("setDisplayProjection",IBinder.class,int.class,Rect.class,Rect.class);
        ProcessBuilder launch=new ProcessBuilder("/system/bin/app_process","/system/bin",RecoveryGuard.class.getName(),Integer.toString(android.os.Process.myPid()));
        launch.environment().put("CLASSPATH",apkPath);launch.redirectError(java.lang.ProcessBuilder.Redirect.to(new File("/dev/null")));
        guard=launch.start();heartbeat=new PrintWriter(guard.getOutputStream(),true);
        ExecutorService reader=Executors.newSingleThreadExecutor();
        try {
            String ready=reader.submit(()->new BufferedReader(new InputStreamReader(guard.getInputStream())).readLine()).get(2,TimeUnit.SECONDS);
            if(!"READY".equals(ready))throw new IOException("Recovery guard unavailable");
            sourceParent=new SurfaceControl.Builder().setName("Poldy logical capture parent").setBufferSize(2448,2448).build();
            source=mirror();
            try(SurfaceControl.Transaction t=new SurfaceControl.Transaction()){
                SurfaceControl.Transaction.class.getMethod("setLayerStack",SurfaceControl.class,int.class).invoke(t,sourceParent,2147483000);
                t.setVisibility(sourceParent,true).setAlpha(sourceParent,1).reparent(source,sourceParent).setVisibility(source,true).setAlpha(source,1).apply();
            }
            projector.scheduleAtFixedRate(()->{
                if(closed||SystemClock.elapsedRealtime()>pinUntil)return;
                try {projectOuter();}catch(Exception e){android.util.Log.e("PoldyControl","projection_failed",e);}
            },0,2,TimeUnit.MILLISECONDS);
        }catch(Exception e){close();throw e;}finally{reader.shutdownNow();}
    }
    private SurfaceControl mirror()throws Exception {
        SurfaceControl result=SurfaceControl.class.getConstructor().newInstance();
        if(!(boolean)api.getMethod("mirrorDisplay",int.class,SurfaceControl.class).invoke(wm,0,result)){
            result.release();throw new IllegalStateException("Logical mirror unavailable");
        }return result;
    }
    void attachLive(SurfaceControl parent)throws Exception {
        if(live!=null)live.release();live=mirror();
        try(SurfaceControl.Transaction t=new SurfaceControl.Transaction()){
            t.reparent(live,parent).setLayer(live,1).setAlpha(live,1).setVisibility(live,true).apply();
        }layoutLive();
    }
    private void layoutLive(){
        if(live==null)return;int w=inner?2448:1248,h=inner?1848:1972;
        FrameFit fit=new FrameFit(w,h,2448,1848);
        try(SurfaceControl.Transaction t=new SurfaceControl.Transaction()){
            t.setCrop(live,new Rect(0,0,w,h)).setScale(live,fit.scale,fit.scale).setPosition(live,fit.x,fit.y).apply();
        }
    }
    void resize(boolean opened)throws Exception {
        if(closed)throw new IllegalStateException("Display session closed");
        if(inner==opened)return;
        pinUntil=SystemClock.elapsedRealtime()+800;projectOuter();
        setSize(opened?2448:1248,opened?1848:1972);inner=opened;layoutLive();projectOuter();
        android.util.Log.i("PoldyControl","logical_resized:"+(inner?"2448x1848":"1248x1972")+", physical=outer");
    }
    private void setSize(int w,int h)throws Exception {
        Class<?> b=Class.forName("com.samsung.android.view.MultiResolutionChangeRequestInfo$Builder");
        Object request=b.getConstructor(int.class).newInstance(0);
        b.getMethod("setWidth",int.class).invoke(request,w);b.getMethod("setHeight",int.class).invoke(request,h);
        b.getMethod("setDensity",int.class).invoke(request,density);b.getMethod("setSaveToSettings",boolean.class).invoke(request,false);
        Object built=b.getMethod("build").invoke(request);api.getMethod("setForcedDisplaySizeDensityWithInfo",built.getClass()).invoke(wm,built);
    }
    private void projectOuter()throws Exception {
        try(SurfaceControl.Transaction t=new SurfaceControl.Transaction()){
            project.invoke(t,outerToken,0,new Rect(0,0,1248,1972),new Rect(0,0,1248,1972));t.apply();
        }
    }
    boolean isInner(){return inner;}
    boolean unlocked()throws Exception{return !(boolean)api.getMethod("isKeyguardLocked").invoke(wm);}
    void renew()throws IOException {if(!guard.isAlive())throw new IOException("Recovery guard stopped");heartbeat.println("BEAT");}
    CapturedFrame capture(NativeFrameCapture capture){return capture.captureLogical(source,inner?2448:1248,inner?1848:1972);}
    @Override public void close(){
        if(closed)return;closed=true;projector.shutdownNow();
        try{projector.awaitTermination(300,TimeUnit.MILLISECONDS);}catch(InterruptedException e){Thread.currentThread().interrupt();}
        boolean restored=false;
        try{api.getMethod("clearForcedDisplaySize",int.class).invoke(wm,0);restored=true;}
        catch(Exception e){android.util.Log.e("PoldyControl","size_restore_failed",e);}
        if(live!=null){live.release();live=null;}if(source!=null){source.release();source=null;}if(sourceParent!=null){sourceParent.release();sourceParent=null;}
        // Keep guard armed until DisplayControl has canceled its device-state request as well.
        if(!restored)heartbeat.close();
    }
    void disarm(){heartbeat.println("DISARM");heartbeat.close();}
}
