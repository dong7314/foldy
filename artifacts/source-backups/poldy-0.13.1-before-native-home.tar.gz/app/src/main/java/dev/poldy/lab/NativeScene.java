package dev.poldy.lab;

import android.os.Parcel;
import android.view.SurfaceControl;
import java.lang.reflect.Method;

/** Shell-owned root layers. Fixed physical stacks for the stable outer-primary session. */
final class NativeScene implements AutoCloseable {
    private final SurfaceControl[] panels=new SurfaceControl[2]; // inner, outer
    private final Method setStack;
    private Boolean innerPrimary;
    private SurfaceControl liveParent;
    NativeScene(boolean inner) throws Exception {
        setStack=SurfaceControl.Transaction.class.getMethod("setLayerStack",SurfaceControl.class,int.class);
        try {
            panels[0]=new SurfaceControl.Builder().setName("Poldy persistent inner").setBufferSize(2448,1848).build();
            panels[1]=new SurfaceControl.Builder().setName("Poldy persistent outer").setBufferSize(1248,1972).build();
            liveParent=new SurfaceControl.Builder().setName("Poldy live inner parent").setBufferSize(2448,1848).build();
            try(SurfaceControl.Transaction t=new SurfaceControl.Transaction()) {
                for(SurfaceControl p:panels)t.setLayer(p,2000000000).setAlpha(p,0).setVisibility(p,true);
                setStack.invoke(t,liveParent,1);
                t.setLayer(liveParent,1999999999).setAlpha(liveParent,1).setVisibility(liveParent,true);
                t.apply();
            }
            route(inner);
        } catch(Exception e){close();throw e;}
    }
    SurfaceControl liveParent(){return liveParent;}
    void route(boolean inner) throws Exception {
        if(innerPrimary!=null&&innerPrimary==inner)return;
        try(SurfaceControl.Transaction t=new SurfaceControl.Transaction()) {
            setStack.invoke(t,panels[0],inner?0:1);setStack.invoke(t,panels[1],inner?1:0);t.apply();
        }
        innerPrimary=inner;
    }
    SurfaceControl[] copies() {
        SurfaceControl[] result=new SurfaceControl[2];
        try {
            for(int i=0;i<2;i++) {
                Parcel p=Parcel.obtain();
                try {panels[i].writeToParcel(p,0);p.setDataPosition(0);result[i]=SurfaceControl.CREATOR.createFromParcel(p);}
                finally {p.recycle();}
            }
            return result;
        } catch(RuntimeException e){for(SurfaceControl p:result)if(p!=null)p.release();throw e;}
    }
    @Override public void close(){
        try(SurfaceControl.Transaction t=new SurfaceControl.Transaction()) {
            for(SurfaceControl p:panels)if(p!=null&&p.isValid())t.setVisibility(p,false).setAlpha(p,0);
            if(liveParent!=null&&liveParent.isValid())t.setVisibility(liveParent,false);
            t.apply();
        } finally {for(int i=0;i<panels.length;i++)if(panels[i]!=null){panels[i].release();panels[i]=null;}if(liveParent!=null){liveParent.release();liveParent=null;}}
    }
}
